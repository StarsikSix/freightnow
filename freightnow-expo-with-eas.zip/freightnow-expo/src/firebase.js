import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyACR_qbdY7BOspvC_1c3Qy65XgkzGn8o4o",
  authDomain: "tailwind-a100.firebaseapp.com",
  projectId: "tailwind-a100",
  storageBucket: "tailwind-a100.firebasestorage.app",
  messagingSenderId: "457926623893",
  appId: "1:457926623893:web:231e608eec4ca56292119c",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
