import React, { useEffect, useState, useMemo } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, Text, TextInput, TouchableOpacity, FlatList, Alert, ActivityIndicator, Image, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { auth, db, storage } from './firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';
import { collection, addDoc, onSnapshot, query, where, serverTimestamp, orderBy, doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const Stack = createNativeStackNavigator();

export default function App() {
  const [user, setUser] = useState(null);
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, u => setUser(u));
    return () => unsub();
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          <Stack.Screen name="Auth" component={AuthScreen} />
        ) : (
          <>
            <Stack.Screen name="Home" component={Home} />
            <Stack.Screen name="DriverOnboarding" component={DriverOnboarding} />
            <Stack.Screen name="CreateJob" component={CreateJob} />
            <Stack.Screen name="JobDetails" component={JobDetails} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

function AuthScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSignUp = async () => {
    try {
      setLoading(true);
      await createUserWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) {
      Alert.alert('Sign up failed', e.message);
    } finally {
      setLoading(false);
    }
  };
  const handleSignIn = async () => {
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) {
      Alert.alert('Sign in failed', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={['#0f172a', '#1e293b']} style={{ flex: 1, padding: 24, justifyContent: 'center' }}>
      <Text style={{ color: 'white', fontSize: 28, fontWeight: '600', marginBottom: 16 }}>FreightNow</Text>
      <Text style={{ color: 'white', opacity: 0.8, marginBottom: 24 }}>Sign in or create your account</Text>
      <TextInput placeholder="Email" placeholderTextColor="#94a3b8" style={styles.input} onChangeText={setEmail} autoCapitalize="none" />
      <TextInput placeholder="Password" placeholderTextColor="#94a3b8" style={styles.input} onChangeText={setPassword} secureTextEntry />
      <TouchableOpacity style={styles.button} onPress={handleSignIn} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Sign In</Text>}
      </TouchableOpacity>
      <TouchableOpacity style={[styles.button, { backgroundColor: '#0ea5e9' }]} onPress={handleSignUp} disabled={loading}>
        <Text style={styles.buttonText}>Create Account</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
}

function Home({ navigation }) {
  const [profile, setProfile] = useState(null);
  const [role, setRole] = useState('driver'); // 'driver' | 'company'
  const [filter, setFilter] = useState({ type: 'all', mode: 'all', highValue: 'all', region: 'all' });
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const uid = auth.currentUser.uid;
    const docRef = doc(db, 'profiles', uid);
    getDoc(docRef).then(d => setProfile(d.exists() ? d.data() : null));

    const q = query(collection(db, 'jobs'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, snap => {
      const arr = [];
      snap.forEach(s => arr.push({ id: s.id, ...s.data() }));
      setJobs(arr);
    });
    return () => unsub();
  }, []);

  const filtered = useMemo(() => {
    return jobs.filter(j => {
      if (filter.type !== 'all' && j.type !== filter.type) return false;
      if (filter.mode !== 'all' && j.truckMode !== filter.mode) return false;
      if (filter.highValue !== 'all' && !!j.highValue !== (filter.highValue === 'yes')) return false;
      if (filter.region !== 'all' && j.region !== filter.region) return false;
      return true;
    });
  }, [jobs, filter]);

  return (
    <View style={{ flex: 1, backgroundColor: '#f1f5f9' }}>
      <View style={{ padding: 16, backgroundColor: 'white', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 20, fontWeight: '600' }}>FreightNow</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Chip label={role === 'driver' ? 'Driver' : 'Company'} onPress={() => setRole(role === 'driver' ? 'company' : 'driver')} />
          <Chip label="Sign out" onPress={() => signOut(auth)} />
        </View>
      </View>

      {!profile && role === 'driver' ? (
        <View style={{ padding: 16 }}>
          <Text style={{ fontSize: 16, marginBottom: 8 }}>Complete driver onboarding to accept jobs.</Text>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('DriverOnboarding')}>
            <Text style={styles.buttonText}>Start Driver Onboarding</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {role === 'company' ? (
        <View style={{ padding: 16 }}>
          <TouchableOpacity style={[styles.button, { backgroundColor: '#0ea5e9' }]} onPress={() => navigation.navigate('CreateJob')}>
            <Text style={styles.buttonText}>Post a Job</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      <Filters filter={filter} setFilter={setFilter} />

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <JobCard item={item} onPress={() => navigation.navigate('JobDetails', { id: item.id })} />}
        contentContainerStyle={{ padding: 16, gap: 12 }}
      />
    </View>
  );
}

function Filters({ filter, setFilter }) {
  const regions = ['all','England - North East','England - North West','Yorkshire and the Humber','East Midlands','West Midlands','East of England','London','South East','South West','Scotland - Highlands & Islands','Scotland - North East','Scotland - Central Belt','Scotland - South','Wales - North','Wales - Mid','Wales - South East','Wales - South West','Northern Ireland - Belfast','Northern Ireland - North','Northern Ireland - South','Northern Ireland - West'];
  const ChipBtn = ({ label, val, prop }) => (
    <TouchableOpacity onPress={() => setFilter({ ...filter, [prop]: filter[prop] === val ? 'all' : val })} style={{ paddingVertical:8, paddingHorizontal:12, borderRadius:16, backgroundColor: filter[prop]===val ? '#0ea5e9' : '#e2e8f0', marginRight:8 }}>
      <Text style={{ color: filter[prop]===val ? 'white' : '#0f172a' }}>{label}</Text>
    </TouchableOpacity>
  );
  return (
    <View style={{ backgroundColor: 'white', padding: 12 }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <ChipBtn label="Urgent" val="urgent" prop="type" />
        <ChipBtn label="Standard" val="standard" prop="type" />
        <ChipBtn label="Own truck" val="own" prop="mode" />
        <ChipBtn label="Truck provided" val="provided" prop="mode" />
        <ChipBtn label="High-Value" val="yes" prop="highValue" />
      </ScrollView>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 8 }}>
        {regions.map(r => (
          <TouchableOpacity key={r} onPress={() => setFilter({ ...filter, region: r })} style={{ paddingVertical:8, paddingHorizontal:12, borderRadius:16, backgroundColor: filter.region===r ? '#0ea5e9' : '#e2e8f0', marginRight:8 }}>
            <Text style={{ color: filter.region===r ? 'white' : '#0f172a' }}>{r}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

function JobCard({ item, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ backgroundColor: 'white', padding: 12, borderRadius: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
        <Text style={{ fontSize: 16, fontWeight: '600' }}>{item.from} → {item.to}</Text>
        {item.type === 'urgent' ? <Text style={{ color: '#dc2626', fontWeight: '700' }}>⚡ Urgent</Text> : <Text style={{ color: '#0f766e', fontWeight: '700' }}>Standard</Text>}
      </View>
      <Text style={{ marginBottom: 4 }}>{item.truckMode === 'own' ? 'Own truck required' : 'Truck provided'}</Text>
      {item.highValue ? <Text style={{ color: '#9333ea', fontWeight: '600' }}>High-Value Cargo</Text> : null}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}>
        <Text>£{item.price}</Text>
        <Text style={{ opacity: 0.7 }}>{item.region}</Text>
      </View>
    </TouchableOpacity>
  );
}

function JobDetails({ route }) {
  const { id } = route.params;
  const [job, setJob] = useState(null);
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'jobs', id), snap => setJob({ id: snap.id, ...snap.data() }));
    return () => unsub();
  }, [id]);

  useEffect(() => {
    const uid = auth.currentUser.uid;
    const docRef = doc(db, 'profiles', uid);
    getDoc(docRef).then(d => setProfile(d.exists() ? d.data() : null));
  }, []);

  const canAccept = () => {
    if (!profile) return false;
    if (job.truckMode === 'own' && !profile.vehicle?.insuranceUrl) return false;
    if (job.highValue && !profile.verifications?.dbs?.verified) return false;
    if (!profile.verifications?.cpc?.verified) return false;
    if (!profile.verifications?.driverCard?.verified) return false;
    if (profile.isNonUKOrIrish && !profile.verifications?.rightToWork?.verified) return false;
    return true;
  };

  const handleAccept = async () => {
    if (!canAccept()) {
      Alert.alert('Cannot accept', 'Your profile does not meet this job requirements.');
      return;
    }
    Alert.alert('Accepted', 'This is a placeholder – implement claim logic in Firestore.');
  };

  if (!job) return <ActivityIndicator style={{ marginTop: 40 }} />;

  return (
    <View style={{ flex: 1, backgroundColor: '#fff', padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>{job.from} → {job.to}</Text>
      <Text style={{ marginVertical: 6 }}>{job.truckMode === 'own' ? 'Own truck required' : 'Truck provided'}</Text>
      {job.highValue ? <Text style={{ color: '#9333ea', fontWeight: '600' }}>High-Value Cargo</Text> : null}
      <Text style={{ marginVertical: 6 }}>Type: {job.type.toUpperCase()}</Text>
      <Text>Region: {job.region}</Text>
      <Text>Window: {job.window}</Text>
      <Text style={{ marginTop: 12, fontSize: 18 }}>£{job.price}</Text>

      <TouchableOpacity style={[styles.button, { marginTop: 16 }]} onPress={handleAccept}>
        <Text style={styles.buttonText}>Accept Job</Text>
      </TouchableOpacity>
    </View>
  );
}

function DriverOnboarding() {
  const uid = auth.currentUser.uid;
  const [uploading, setUploading] = useState(false);
  const [state, setState] = useState({
    nationality: 'UK',
    regions: [],
    hasOwnTruck: false,
    verifications: {
      cpc: { url: null, verified: false },
      driverCard: { url: null, verified: false },
      rightToWork: { url: null, verified: false },
      dbs: { url: null, verified: false },
      licence: { url: null, verified: false },
      idDoc: { url: null, verified: false }
    },
    vehicle: {}
  });

  const pickDoc = async (key) => {
    const res = await DocumentPicker.getDocumentAsync({ type: ['image/*','application/pdf'] });
    if (res.canceled) return;
    const file = res.assets[0];
    await uploadToStorage(file, key);
  };

  const uploadToStorage = async (file, key) => {
    try {
      setUploading(true);
      const blob = await (await fetch(file.uri)).blob();
      const storageRef = ref(storage, `drivers/${uid}/${key}-${Date.now()}`);
      await uploadBytes(storageRef, blob);
      const url = await getDownloadURL(storageRef);
      setState(prev => ({
        ...prev,
        verifications: {
          ...prev.verifications,
          [key]: { url, verified: false }
        }
      }));
      await setDoc(doc(db, 'profiles', uid), {
        ...state,
        verifications: {
          ...state.verifications,
          [key]: { url, verified: false }
        }
      }, { merge: true });
    } catch (e) {
      Alert.alert('Upload failed', e.message);
    } finally {
      setUploading(false);
    }
  };

  const saveBasics = async () => {
    await setDoc(doc(db, 'profiles', uid), state, { merge: true });
    Alert.alert('Saved', 'Profile saved. Verification pending.');
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff', padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>Driver Onboarding</Text>
      <Text style={{ marginTop: 8 }}>Upload required documents. Some jobs (High-Value) require DBS.</Text>

      <Section title="Identity & Driving Licence">
        <UploadRow label="ID / Passport or UK Photo Licence" onPress={() => pickDoc('idDoc')} />
        <UploadRow label="Driving Licence (C/C+E)" onPress={() => pickDoc('licence')} />
      </Section>

      <Section title="Qualifications">
        <UploadRow label="CPC Card (Driver Qualification Card)" onPress={() => pickDoc('cpc')} />
        <UploadRow label="Tachograph Driver Card" onPress={() => pickDoc('driverCard')} />
      </Section>

      <Section title="Right to Work (if Non‑UK/Irish)">
        <UploadRow label="Right to Work proof (share code PDF or BRP)" onPress={() => pickDoc('rightToWork')} />
      </Section>

      <Section title="High‑Value Cargo">
        <UploadRow label="DBS Check (Basic) document" onPress={() => pickDoc('dbs')} />
      </Section>

      <Section title="Vehicle (only if Own Truck)">
        <UploadRow label="Insurance certificate" onPress={() => pickDoc('insurance')} />
        <UploadRow label="MOT certificate" onPress={() => pickDoc('mot')} />
      </Section>

      <TouchableOpacity style={[styles.button, { marginTop: 16 }]} onPress={saveBasics} disabled={uploading}>
        {uploading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Save Profile</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

function Section({ title, children }) {
  return (
    <View style={{ marginTop: 16 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 8 }}>{title}</Text>
      <View style={{ gap: 8 }}>{children}</View>
    </View>
  );
}

function UploadRow({ label, onPress }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#f8fafc', padding: 12, borderRadius: 10 }}>
      <Text>{label}</Text>
      <TouchableOpacity onPress={onPress} style={{ paddingHorizontal: 12, paddingVertical: 8, backgroundColor: '#0ea5e9', borderRadius: 8 }}>
        <Text style={{ color: 'white' }}>Upload</Text>
      </TouchableOpacity>
    </View>
  );
}

function CreateJob({ navigation }) {
  const [form, setForm] = useState({
    from: '',
    to: '',
    price: '',
    type: 'standard',
    truckMode: 'own',
    highValue: false,
    region: 'London',
    window: 'Today 14:00–18:00'
  });

  const create = async () => {
    try {
      if (!form.from || !form.to || !form.price) return Alert.alert('Missing fields', 'Please fill in origin, destination and price.');
      await addDoc(collection(db, 'jobs'), {
        ...form,
        price: Number(form.price),
        createdAt: serverTimestamp(),
      });
      Alert.alert('Posted', 'Job posted successfully.');
      navigation.goBack();
    } catch (e) {
      Alert.alert('Failed', e.message);
    }
  };

  const Input = ({ label, value, onChangeText, keyboardType='default' }) => (
    <View style={{ marginBottom: 8 }}>
      <Text style={{ marginBottom: 4 }}>{label}</Text>
      <TextInput value={value} onChangeText={onChangeText} keyboardType={keyboardType} style={styles.inputLight} />
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff', padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>Post a Job</Text>
      <Input label="From" value={form.from} onChangeText={(t)=>setForm({...form, from:t})} />
      <Input label="To" value={form.to} onChangeText={(t)=>setForm({...form, to:t})} />
      <Input label="Price (£)" value={form.price} onChangeText={(t)=>setForm({...form, price:t})} keyboardType="numeric" />
      <Input label="Time Window" value={form.window} onChangeText={(t)=>setForm({...form, window:t})} />

      <Row>
        <Chip label={form.type==='urgent'?'⚡ Urgent':'Standard'} onPress={()=>setForm({...form, type: form.type==='urgent'?'standard':'urgent'})} />
        <Chip label={form.truckMode==='own'?'Own truck':'Truck provided'} onPress={()=>setForm({...form, truckMode: form.truckMode==='own'?'provided':'own'})} />
        <Chip label={form.highValue? 'High‑Value: Yes':'High‑Value: No'} onPress={()=>setForm({...form, highValue: !form.highValue})} />
      </Row>

      <RegionPicker value={form.region} onChange={(r)=>setForm({...form, region:r})} />

      <TouchableOpacity style={[styles.button, { marginTop: 16 }]} onPress={create}>
        <Text style={styles.buttonText}>Create</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function RegionPicker({ value, onChange }) {
  const regions = ['England - North East','England - North West','Yorkshire and the Humber','East Midlands','West Midlands','East of England','London','South East','South West','Scotland - Highlands & Islands','Scotland - North East','Scotland - Central Belt','Scotland - South','Wales - North','Wales - Mid','Wales - South East','Wales - South West','Northern Ireland - Belfast','Northern Ireland - North','Northern Ireland - South','Northern Ireland - West'];
  return (
    <View style={{ marginTop: 8 }}>
      <Text style={{ marginBottom: 6 }}>Region</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {regions.map(r => (
          <TouchableOpacity key={r} onPress={()=>onChange(r)} style={{ paddingHorizontal: 12, paddingVertical: 8, backgroundColor: value===r ? '#0ea5e9' : '#e2e8f0', borderRadius: 16, marginRight: 8 }}>
            <Text style={{ color: value===r ? 'white' : '#0f172a' }}>{r}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

function Row({ children }) {
  return <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>{children}</View>;
}

function Chip({ label, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ backgroundColor: '#0ea5e9', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 16 }}>
      <Text style={{ color: 'white', fontWeight: '600' }}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = {
  input: { backgroundColor: '#0b1220', color: 'white', padding: 12, borderRadius: 10, marginBottom: 10 },
  button: { backgroundColor: '#16a34a', padding: 12, alignItems: 'center', borderRadius: 10 },
  buttonText: { color: 'white', fontWeight: '700' },
  inputLight: { backgroundColor: '#f1f5f9', padding: 10, borderRadius: 8 }
};
