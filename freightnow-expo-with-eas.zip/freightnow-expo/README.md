# FreightNow (Expo React Native – UK)

A minimal MVP you can run on your phone with Expo Go. Includes:
- Email/Password auth
- Driver onboarding with document uploads (CPC, Driver Card, Right to Work, DBS for High‑Value)
- Jobs feed with filters (Urgent/Standard, Own truck/Truck provided, High‑Value, UK regions)
- Post a Job (company role)
- Placeholders for accept-flow & escrow

## Quick start

1) **Install prerequisites**
- Install Node.js (LTS)
- Install Expo CLI: `npm i -g expo`
- Install Android Studio (for emulator) or use Expo Go app on your phone (recommended).

2) **Download & install**
- Unzip this project.
- In the project folder run: `npm install`

3) **Create Firebase project**
- Go to https://console.firebase.google.com → Add project
- Enable **Authentication** (Email/Password)
- Enable **Firestore** (in Test mode for dev)
- Enable **Storage**

4) **Create a Web App in Firebase**
- In Firebase Console → Project settings → Your apps → Web app
- Copy the config and put values into `.env` file in project root:

```
EXPO_PUBLIC_FIREBASE_API_KEY=...
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=...
EXPO_PUBLIC_FIREBASE_PROJECT_ID=...
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=...
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=...
EXPO_PUBLIC_FIREBASE_APP_ID=...
```

5) **(Optional) Firestore Security Rules (dev-safe)**
In Firebase Console → Firestore → Rules set to:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /jobs/{jobId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    match /profiles/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

**Storage rules** (dev-safe):
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /drivers/{userId}/{allPaths=**} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

6) **Run the app**
- Start dev server: `npm run start`
- Scan the QR code with **Expo Go** on your phone (Android/iOS).

7) **Use the app**
- Create an account (email/password).
- If you are a **driver**, open **Driver Onboarding** and upload required docs.
- If you are a **company**, switch role to Company (top right) → **Post a Job**.
- Jobs appear in the feed; filters at the top let you view Urgent/Standard, Own/Provided, High‑Value, and UK regions.

## Implementing Accept & Escrow (next steps)

- Add a subcollection `claims` on each `jobs/{jobId}` where driver writes `{driverId, timestamp}` on accept (check preconditions).
- Use Cloud Functions to enforce business rules (DBS required for `highValue`, insurance for `own`).
- Integrate Stripe Connect for escrow (capture from company → release to driver minus platform fee).

## Notes

- This is an MVP for demonstration/testing. Harden rules, add admin review for documents, and proper status flow before production.


## Build APK in the cloud (from your phone)
1) Create a free account at https://expo.dev and install the Expo Go app on your phone.
2) Push this project to a new GitHub repo (you can use the GitHub mobile app).
3) Go to https://expo.dev/accounts -> Projects -> New -> Link your GitHub repo.
4) In the project page, start a build with profile `preview-apk` (defined in eas.json). This will produce an **APK**.
5) When the build finishes, download the APK directly to your Android phone and install it.

If you prefer the command line, run `npx expo login`, then `npx eas build -p android --profile preview-apk`.
